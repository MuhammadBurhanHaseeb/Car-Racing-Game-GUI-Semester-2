﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
namespace FrameWork.Core
{
    public class Label
    {
        //List<Label> labelsList = new List<Label>();
        //  private int scoreLabel;
        //  public Label (   int width , int height  , int x , int y )
        //{

        //}
        /*  score = new Label();
          score.Size = new Size(111, 52);
          score.BackColor = Color.Transparent;
              Font MediumFont = new Font("ArialBold", 14);

          public int ScoreLabel { get => scoreLabel; set => scoreLabel = value; }
          public List<Label> LabelsList { get => labelsList; set => labelsList = value; }

          public void addIntoList()
          {

          }

          public void ScoreUpdate()
          {

          }

          score.Font = MediumFont;
              location.X = 10;
              location.Y = 1;
         *///     score.Location = location;
      }
         

    }
     